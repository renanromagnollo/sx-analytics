import { db } from "@/db";
import { attendances, professionals, services } from "@/db/schema";

type Gendo304Row = {
  date: string;
  professional: string;
  service: string;
  totalAmount: number;
  clientName?: string;
};

export async function importGendo304(rows: Gendo304Row[], salonId: string) {
  let imported = 0;
  let invalid = 0;

  for (const row of rows) {
    try {
      // 1. encontrar profissional
      const professional = await db.query.professionals.findFirst({
        where: (p, { eq }) =>
          eq(p.name, row.professional),
      });

      if (!professional) {
        invalid++;
        continue;
      }

      // 2. encontrar serviço
      const service = await db.query.services.findFirst({
        where: (s, { eq }) =>
          eq(s.name, row.service),
      });

      if (!service) {
        invalid++;
        continue;
      }

      // 3. inserir attendance
      const [attendance] = await db
        .insert(attendances)
        .values({
          salonId,
          professionalId: professional.id,
          clientName: row.clientName ?? null,
          totalAmount: String(row.totalAmount),
          attendanceDate: new Date(row.date),
        })
        .returning();

      // 4. (IMPORTANTE) vínculo serviço
      await db.insert(attendanceServices).values({
        attendanceId: attendance.id,
        serviceId: service.id,
      });

      imported++;
    } catch (err) {
      invalid++;
    }
  }

  return {
    imported,
    invalid,
  };
}