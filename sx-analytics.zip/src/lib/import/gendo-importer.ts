import { db } from "@/db";
import { attendances, attendanceServices } from "@/db/schema";

export async function importGendo304(rows: any[], salonId: string) {
  let imported = 0;
  let invalid = 0;

  for (const row of rows) {
    try {
      const professional = await db.query.professionals.findFirst({
        where: (p, { eq }) => eq(p.name, row.professional),
      });

      if (!professional) {
        invalid++;
        continue;
      }

      const service = await db.query.services.findFirst({
        where: (s, { eq }) => eq(s.name, row.service),
      });

      if (!service) {
        invalid++;
        continue;
      }

      const [attendance] = await db
        .insert(attendances)
        .values({
          salonId,
          professionalId: professional.id,
          clientName: row.clientName ?? null,
          totalAmount: String(row.totalAmount),
          attendanceDate: new Date(row.date),
        })
        .returning();

      await db.insert(attendanceServices).values({
        attendanceId: attendance.id,
        serviceId: service.id,
      });

      imported++;
    } catch (e) {
      invalid++;
    }
  }

  return { imported, invalid };
}