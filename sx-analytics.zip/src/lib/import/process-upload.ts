import { db } from "@/db";
import { uploads } from "@/db/schema";

import { parseGendo304File } from "./gendo-parser";
import { importGendo304 } from "./gendo-importer";

type UploadStatus = "processing" | "done" | "error";

export async function processUpload(
  uploadId: string,
  buffer: Buffer,
  salonId: string
) {
  await db
    .update(uploads)
    .set({
      status: "processing" satisfies UploadStatus,
      startedAt: new Date(),
    })
    .where((u, { eq }) => eq(u.id, uploadId));

  try {
    const rows = parseGendo304File(buffer);

    const result = await importGendo304(rows, salonId);

    await db
      .update(uploads)
      .set({
        status: "done" satisfies UploadStatus,
        importedRows: result.imported,
        invalidRows: result.invalid,
        finishedAt: new Date(),
      })
      .where((u, { eq }) => eq(u.id, uploadId));
  } catch (err: any) {
    await db
      .update(uploads)
      .set({
        status: "error" satisfies UploadStatus,
        errorMessage: err?.message ?? "Unknown error",
        finishedAt: new Date(),
      })
      .where((u, { eq }) => eq(u.id, uploadId));
  }
}