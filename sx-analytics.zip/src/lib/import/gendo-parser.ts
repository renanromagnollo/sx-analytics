import * as XLSX from "xlsx";

export type Gendo304Row = {
  date: string;
  professional: string;
  service: string;
  totalAmount: number;
  clientName?: string;
};

export function parseGendo304(buffer: Buffer): Gendo304Row[] {
  const workbook = XLSX.read(buffer, { type: "buffer" });

  const sheet = workbook.Sheets[workbook.SheetNames[0]];

  const data = XLSX.utils.sheet_to_json(sheet);

  return data.map((row: any) => ({
    date: row["Data"],
    professional: row["Profissional"],
    service: row["Serviço"],
    totalAmount: Number(row["Valor"]),
    clientName: row["Cliente"] ?? null,
  }));
}