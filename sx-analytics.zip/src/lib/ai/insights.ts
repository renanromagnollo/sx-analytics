import { calculateGrowth } from "@/lib/analytics/comparison";

type Insight = {
  type: "positive" | "negative" | "info";
  title: string;
  description: string;
};

export function generateRevenueInsights(input: {
  currentRevenue: number;
  previousRevenue: number;
}) {
  const growth = calculateGrowth(
    input.currentRevenue,
    input.previousRevenue
  );

  const insights: Insight[] = [];

  if (growth <= -10) {
    insights.push({
      type: "negative",
      title: "Queda de faturamento",
      description: `Receita caiu ${growth.toFixed(1)}% em relação ao período anterior`,
    });
  }

  if (growth >= 10) {
    insights.push({
      type: "positive",
      title: "Crescimento de faturamento",
      description: `Receita cresceu ${growth.toFixed(1)}% em relação ao período anterior`,
    });
  }

  if (growth > -10 && growth < 10) {
    insights.push({
      type: "info",
      title: "Estabilidade de receita",
      description: `Variação de ${growth.toFixed(1)}% no período`,
    });
  }

  return insights;
}