import { pgTable, uuid, text, timestamp, integer, varchar } from "drizzle-orm/pg-core";
import { salons } from "./salons";

export const uploads = pgTable("uploads", {
  id: uuid("id").defaultRandom().primaryKey(),

  salonId: uuid("salon_id")
    .references(() => salons.id)
    .notNull(),

  fileName: varchar("file_name", { length: 255 }).notNull(),

  status: varchar("status", { length: 50 }).notNull(),

  importedRows: integer("imported_rows").default(0).notNull(),

  invalidRows: integer("invalid_rows").default(0).notNull(),

  errorMessage: text("error_message"),

  startedAt: timestamp("started_at").defaultNow().notNull(),

  finishedAt: timestamp("finished_at"),
});