import Link from "next/link";

export function Sidebar() {
  return (
    <aside
      className="
        w-64
        border-r
        bg-background
        p-6
      "
    >
      <div className="mb-10">

        <h1 className="text-2xl font-bold">
          SX Analytics
        </h1>

        <p className="text-sm text-muted-foreground">
          Intelligence Platform
        </p>

      </div>

      <nav className="space-y-2">

        <Link
          href="/dashboard"
          className="
            block
            rounded-lg
            px-4
            py-3
            hover:bg-muted
            transition
          "
        >
          Dashboard
        </Link>

        <Link
          href="/upload"
          className="
            block
            rounded-lg
            px-4
            py-3
            hover:bg-muted
            transition
          "
        >
          Uploads
        </Link>

      </nav>
    </aside>
  );
}